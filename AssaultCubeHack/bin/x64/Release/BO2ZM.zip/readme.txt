Project name : VECR PROJECT
Software name : Bloodshed
Game name : Call of Duty: Black Ops 2 ZM
Launcher name : Plutonium
Created by : Probably


META TAG (title): VECR PROJECT

META TAG (description): VECR PROJECT - Your Cheats and Hacks for Plutonium/XLAB/SM2 with different features.

--------------------------------------------------------------
 

 Menu

 VECR PROJECT 
 

 WORKING IN PROGRESS V E C R PROJECT

 Your complete and optimized HACKS / CHEATS 100% FRENCH. 

 More Info

 

 

 • • • • 

 

 

 COMPLETE PRESENTATION

 

 

 

 Regularly updated and secure software. You can download our software without any problem with automatic update and you can trust that we are not here to steal or hack your private information.

 

 

 Direct access via the discord server. Join us via discord server for talking with the community and getting the download link access.

 

 

 

 

 Fast support. If you have any question do not hesitate to open a ticket from discord server. Any support or Admin respond you quickly. We are at your service..

 

 

 We are not machines. We have a website that is totally unbundled from a database. Unlike other solutions, there is no need to collect your personal data. Even the cookies are not used on our site or even the nasty ads that bother your head.

 

 

 

 

 Safe And Secure. Our software is secure and safe to use. The whole TEAM participates and collaborates to make sure everything is in order. For any question or in case of major problem please join us on Discord.

 

 

 Best cost for premium version. We try to offer you at the best price the different software that are at your disposal. We even make time-limited offers.

 

 

 Contact Us DISCORD Show prices DOWNLOAD

 

 

 

 HOW IT WORKS ?

 

 

 

 

 

 

 Information about our software. 

 The software use .NET FRAMEWORK 4.7 in VB.NET & C# languages. This is a external program and the software don't replace anything into the game memory for safe the ban only your gameplay affect your ban account. 

 

 

 

 How did we get around the anti-cheating system ? 

 Our program uses all kinds of features to remain undetectable by the anti-cheating system. Of course you will be notified as soon as our software is detected by the anti cheat. 

 

 

 

 

 

 

 

 

 AVAILABLE PROGRAM LISTS

 

 

 

 

 

 

 VECR PROJECT FOR PLUTONIUM

 Call Of Duty: Black Ops: ✅ Call Of Duty: Black Ops II: ✅ Call Of Duty: Modern Warfare 3: ✅ Call Of Duty: World At War: ❌ 

 

 

 

 

 

 VECR PROJECT FOR XLAB

 Call Of Duty: Modern Warfare 2: ❌ Call Of Duty: GHOST: ❌ Call Of Duty: Advanced Warfare: ❌ 

 

 

 

 

 

 VECR PROJECT FOR SM2

 Call Of Duty: Modern Warfare 2: ❌ 

 

 

 

 

 

 

 

 FULL FEATURES LISTS

 

 

 

 

 [AIMBOT FUNCTIONS]

 • AIMBOT Button ON/OFF • Acceleration TrackBar • Aim FOV TrackBar • Show aim FOV Button ON/OFF • Priority SelectButton • Target SelectButton • Aim Key Button ON/OFF • Auto Fire Button ON/OFF 

 

 

 

 

 

 

 Aimbot Automatically aim at players when you press the Aim Key. 

 Close 

 

 

 

 Acceleration Modify speed sensitivity for the aimbot. 

 Close 

 

 

 

 Aim FOV Change the size of your vision circle. 

 Close 

 

 

 

 Show Aim FOV You can choose if you want to see the circle or not. 

 Close 

 

 

 

 Priority Prioritize targets closest to crosshair or closest to you. 

 Close 

 

 

 

 Target Select your specified focused targeting body (HEAD,BODY,FOOT). 

 Close 

 

 

 

 Aim Key Change your keybind for active the AIMBOT. 

 Close 

 

 

 

 Auto Fire If you have a semi-automatic weapon, the software will shoot for you. 

 Close 

 

 

 

 

 

 

 

 [ESP FUNCTIONS]

 • ESP Button ON/OFF • Show Allies Button ON/OFF • Box Form Button Switch • Box Size Button Switch • Show Name Button ON/OFF • Show Distance Button ON/OFF 

 

 

 

 

 

 

 ESP (Extra Sensory Perception) Active this function for showing each enemies or allies in your field of view. 

 Close 

 

 

 

 Show Allies You can active this function for showing your allies into your field of view. 

 Close 

 

 

 

 Box Form Change the ESP form like how you want. 

 Close 

 

 

 

 Box Size Modify the size of your ESP Form. 

 Close 

 

 

 

 Show Name You can display the name of each player above ESP. 

 Close 

 

 

 

 Show Distance You can display the distance of each player above ESP. 

 Close 

 

 

 

 

 

 

 

 [SNAPLINE FUNCTIONS]

 • SNAPLINE Button ON/OFF • Line Size TrackBar • Starting Point Button Switch 

 

 

 

 

 

 

 SNAPLINE Draws lines from you to other players. 

 Close 

 

 

 

 Line Size Change the size of each drawing line. 

 Close 

 

 

 

 Starting Point Choice the drawing starting point of your line. 

 Close 

 

 

 

 

 

 

 

 [STYLES FUNCTIONS]

 • Enemies Box Custom Color • Allies Box Custom Color • Border Box Custom Color • Line Color Custom Color • Crosshair Color Custom Color • Aim FOV Color Custom Color 

 

 

 

 

 

 

 Enemies Box Change the ESP enemies color. 

 Close 

 

 

 

 Allies Box Change the ESP allies color. 

 Close 

 

 

 

 Border Box Change the ESP (FORM 2) color. 

 Close 

 

 

 

 Line Color Change the SNAPLINE color. 

 Close 

 

 

 

 Crosshair Color Change the crosshair color. 

 Close 

 

 

 

 Aim FOV Color Change the AIM FOV color. 

 Close 

 

 

 

 

 

 

 

 [MISC FUNCTIONS]

 • CROSSHAIR Button ON/OFF • VSAT Button ON/OFF • Crosshair Size TrackBar • Crosshair Thickness TrackBar • Text Size TrackBar 

 

 

 

 

 

 

 CROSSHAIR Shows a crosshair in the middle of your screen. 

 Close 

 

 

 

 VSAT Shows all players in your radar. 

 Close 

 

 

 

 Crosshair Size Modify the size of your crosshair. 

 Close 

 

 

 

 Crosshair Thickness Modify the thickness of your crosshair. 

 Close 

 

 

 

 Text Size Change the text size that appears above your ESP. 

 Close 

 

 

 

 

 

 

 

 [SETTINGS FUNCTIONS]

 • FPS TrackBar • Show FPS Button ON/OFF • VSYNC Button ON/OFF • Show Menu Button ON/OFF • Show Overlay Button ON/OFF • CONFIG.INI Configuration 

 

 

 

 

 

 

 FPS Increase or Decrease your specified value of your Frame Per Second. 

 Close 

 

 

 

 Show FPS You can display how much FPS you have on screen. 

 Close 

 

 

 

 VSYNC Enable or disable this feature to remove FPS synchronization. 

 Close 

 

 

 

 Show Menu Change your keybind for showing the MENU. 

 Close 

 

 

 

 Show Overlay You can display the overlay on screen. 

 Close 

 

 

 

 CONFIG.INI Select/Create/Change the profile setting you have chosen. 

 Close 

 

 

 

 

 

 

 

 PREMIUM VERSION PRICING

 Unlock many special features by buying the premium version. 

 PREMIUM VERSION: [AIMBOT] [ESP] [SNAPLINE] [STYLES] [MISC] [SETTINGS] 

 

 STEPS TO FOLLOW: 1- Get your amazon FRENCH card or cashlib. 2- Join our discord and open a ticket to notify the admin that you have made your request. 3- After your request have been accepted, follow instruction gived by the admin

 

 Pay in complete safety and 100 % guaranteed. Choose your package. 

 

 

 

 COMPLETE PACK GAME BLUE CARD | AMAZON FRENCH CARD | CASHLIB 

 30 € / LIFETIME Send donation here 

 

 

 

 

 FREQUENTLY ASKED QUESTIONS

 

 

 OMG ! VIRUS ? 

 Yes certain behaviours of our software might be considered as malicious by your antivirus. They are false positives. Our software is designed to simulate mouse movement and keyboard typing to actually play the game. This is a common trigger for anti-virus engines. In order to work properly, the software is using your network traffic to check if an update is available and to grant full access to premium users. The software is also creating/writing and reading a configuration file in order to save your settings. The software source code is obfuscated to prevent it being easily stolen. This alone is enough to trigger multiple anti-virus engines. If after all you remain unconvinced, dont use this software.

 WHERE I CAN DOWNLOAD THE LATEST SOFTWARE VERSION ? 

 Join our discord and check out the DOWNLOAD channel.

 HOW I CAN UNBAN ME ? 

 If you have getting ban from a specified server you can unban you with create another account and changing your IP. If you have ban from the owner server a good software exist for spoof your computer: SPOOFER DOWNLOAD LINK.

 THE SOFTWARE DOES NOT START CORRECTLY ? 

 Make sure your game is WINDOWED MODE. Press F1 after overlay appear. If your problem persist join our discord and open a Ticket.

 HOW I CAN RESET MY LICENSE ? 

 Make your request from our discord.

 

 

 

 

 CONTACT US

 

 

 Join our discord for more questions. You can open a ticket to notify an admin. We will get back to you within 24 hours.

 

 

 

 

 Informations

 Discord: https://discord.gg/DhkSVvJpJw We are a small team of computer enthusiasts. The challenge allows us to surpass our limits, which makes us even stronger. 

 

 

 

 Contact From

 Paris, France vecrproject@protonmail.com 

 

 

 

 Support/TEAM

 Project Creator: Probably Dev Discord: SKURTLR | Tyrallis Admin: Legacy | Imperf3ct | Roxas | Yahes

 

 

 

 

 

 

 • • • • 

 

 © Copyright VECR 2020-2022. Terms of service Redesigned by Probably




[FR]

Présentation : 

Ce logiciel a pour but de tricher sur un jeu à la première personne.
Le programme utilise la mémoire du jeu afin de lire chaque détail que l'on veut voir à l'écran.
Il permet de visualiser des ennemis à travers les murs et de faire pas mal de modification à l'écran
que cela soit l'interface visuelle ou le jeu en lui même afin de rendre l'ergonomie et l'utilisation du logiciel le plus complet possible.

Objectif personnel :
Ce projet avait été créer dans l'unique but d'apprendre par curiosité.

Ce projet m'a permis de découvrir comment fonctionnait le language machine (assembleur).
Le reverse engineering d'un programme pour modifier ses propriétées.
Création de fonctions qui calculent les angles pour positionner et dessiner correctement, la position, la distance  "matrix", "Vecteur", "AxisAlignedBox".
Utilisation de l'API DirectX et la bibliothèque SharpDX pour créer des formes à l'écran.
                        